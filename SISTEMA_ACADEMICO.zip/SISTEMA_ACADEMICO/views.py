from abc import ABC, abstractmethod
from models import Estudiante, Materia, Matricula
from shared.json_manager import GestorJSON
from shared.herramientas import es_email_valido

class CrudBase(ABC):
    @abstractmethod
    def leer(self): pass
    @abstractmethod
    def obtener(self, id_registro): pass
    @abstractmethod
    def buscar(self, texto): pass
    @abstractmethod
    def siguiente(self): pass
    @abstractmethod
    def crear(self, datos): pass
    @abstractmethod
    def actualizar(self, id_registro, datos): pass
    @abstractmethod
    def eliminar(self, id_registro): pass


class EstudianteController(CrudBase):
    def __init__(self, archivo="data/estudiantes.json"):
        self.gestor = GestorJSON(archivo)
        self.lista = [Estudiante.desde_diccionario(d) for d in self.gestor.leer()]

    def guardar(self):
        self.gestor.guardar([e.a_diccionario() for e in self.lista])

    def validar(self, datos, id_actual=None):
        if id_actual is None:
            for campo in ("nombre", "apellido", "email", "carnet"):
                if str(datos.get(campo, "")).strip() == "":
                    return f"El campo {campo} es obligatorio"

        if "email" in datos:
            email = str(datos["email"]).strip().lower()
            if not es_email_valido(email): return f"Email inválido: '{email}'"
            usados = {e.email for e in self.lista if e.id != id_actual}
            if email in usados: return "Ese email ya está registrado"

        if "carnet" in datos:
            carnet = str(datos["carnet"]).strip().upper()
            usados_carnet = {e.carnet.upper() for e in self.lista if e.id != id_actual}
            if carnet in usados_carnet: return "Ese carnet ya está registrado"
        return None

    def leer(self): return self.lista
    def obtener(self, id_est): return next((e for e in self.lista if e.id == id_est), None)
    
    def buscar(self, texto):
        t = texto.strip().lower()
        if not t: return []
        return [e for e in self.lista if t in e.nombre.lower() or t in e.apellido.lower() or t in e.carnet.lower()]

    def siguiente(self):
        return (max([e.id for e in self.lista], default=0)) + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error: return False, error
        est = Estudiante(self.siguiente(), str(datos["nombre"]).strip().title(),
                         str(datos["apellido"]).strip().title(), str(datos["email"]).strip().lower(),
                         str(datos["carnet"]).strip().upper(), str(datos.get("carrera", "")).strip().title())
        self.lista.append(est)
        self.guardar()
        return True, f"Estudiante creado: {est.etiqueta()}"

    def actualizar(self, id_est, datos):
        est = self.obtener(id_est)
        if not est: return False, f"No existe estudiante con id {id_est}"
        error = self.validar(datos, id_est)
        if error: return False, error
        for k, v in datos.items():
            if v: setattr(est, k, str(v).strip())
        self.guardar()
        return True, f"Estudiante {id_est} actualizado"

    def eliminar(self, id_est):
        est = self.obtener(id_est)
        if not est: return False, f"No existe estudiante con id {id_est}"
        self.lista.remove(est)
        self.guardar()
        return True, f"Estudiante {id_est} eliminado"

    def carreras(self):
        return sorted({e.carrera for e in self.lista if e.carrera})


class MateriaController(CrudBase):
    def __init__(self, archivo="data/materias.json"):
        self.gestor = GestorJSON(archivo)
        self.lista = [Materia.desde_diccionario(d) for d in self.gestor.leer()]

    def guardar(self):
        self.gestor.guardar([m.a_diccionario() for m in self.lista])

    def validar(self, datos, id_actual=None):
        if id_actual is None:
            for campo in ("nombre", "codigo"):
                if str(datos.get(campo, "")).strip() == "": return f"El campo {campo} es obligatorio"
        
        if "codigo" in datos:
            cod = str(datos["codigo"]).strip().upper()
            if any(m.codigo.upper() == cod and m.id != id_actual for m in self.lista):
                return "Ese código de materia ya existe"
        return None

    def leer(self): return self.lista
    def obtener(self, id_mat): return next((m for m in self.lista if m.id == id_mat), None)
    
    def buscar(self, texto):
        t = texto.strip().lower()
        return [m for m in self.lista if t in m.nombre.lower() or t in m.codigo.lower()]

    def siguiente(self):
        return (max([m.id for m in self.lista], default=0)) + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error: return False, error
        mat = Materia(self.siguiente(), str(datos["nombre"]).strip().title(),
                      str(datos["codigo"]).strip().upper(), int(datos.get("creditos", 3)), int(datos.get("cupos", Materia.CUPOS_MAXIMOS)))
        self.lista.append(mat)
        self.guardar()
        return True, f"Materia creada: {mat.etiqueta()}"

    def actualizar(self, id_mat, datos):
        mat = self.obtener(id_mat)
        if not mat: return False, "Materia no encontrada"
        error = self.validar(datos, id_mat)
        if error: return False, error
        for k, v in datos.items():
            if v: setattr(mat, k, int(v) if k in ("creditos", "cupos") else str(v).strip())
        self.guardar()
        return True, f"Materia {id_mat} actualizada"

    def eliminar(self, id_mat):
        mat = self.obtener(id_mat)
        if not mat: return False, "Materia no encontrada"
        self.lista.remove(mat)
        self.guardar()
        return True, f"Materia {id_mat} eliminada"

    def sin_cupo(self):
        return [m for m in self.lista if not m.hay_cupo()]


class MatriculaController(CrudBase):
    def __init__(self, estudiantes, materias, archivo="data/matriculas.json"):
        self.estudiantes = estudiantes
        self.materias = materias
        self.gestor = GestorJSON(archivo)
        self.lista = [Matricula.desde_diccionario(d) for d in self.gestor.leer()]

    def guardar(self):
        self.gestor.guardar([mt.a_diccionario() for mt in self.lista])

    def validar(self, datos):
        try:
            est_id = int(datos.get("estudiante_id", 0))
            mat_id = int(datos.get("materia_id", 0))
            nota = float(datos.get("nota", 0.0))
        except (TypeError, ValueError):
            return "IDs y nota deben ser valores numéricos"

        if not self.estudiantes.obtener(est_id): return f"No existe estudiante con id {est_id}"
        mat = self.materias.obtener(mat_id)
        if not mat: return f"No existe materia con id {mat_id}"
        if not mat.hay_cupo(): return f"La materia {mat.nombre} no tiene cupos disponibles"
        if not Materia.es_nota_valida(nota): return "Nota inválida (debe estar entre 0 y 20)"
        
        periodo = str(datos.get("periodo", "")).strip()
        if any(mt.estudiante_id == est_id and mt.materia_id == mat_id and mt.periodo == periodo for mt in self.lista):
            return "El estudiante ya está matriculado en esta materia para este periodo"
        return None

    def leer(self): return self.lista
    def obtener(self, id_mt): return next((mt for mt in self.lista if mt.id == id_mt), None)
    
    def buscar(self, texto):
        t = texto.strip()
        return [mt for mt in self.lista if t in mt.periodo]

    def siguiente(self):
        return (max([mt.id for mt in self.lista], default=0)) + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error: return False, error
        
        mat = self.materias.obtener(int(datos["materia_id"]))
        mt = Matricula(self.siguiente(), int(datos["estudiante_id"]), mat.id,
                       str(datos["periodo"]).strip(), float(datos.get("nota", 0.0)))
        mat.ocupar_cupo()
        self.materias.guardar()
        self.lista.append(mt)
        self.guardar()
        return True, f"Matrícula registrada con éxito por nota {mt.nota}"

    def actualizar(self, id_mt, datos):
        mt = self.obtener(id_mt)
        if not mt: return False, "Matrícula no encontrada"
        if "nota" in datos:
            nueva_nota = float(datos["nota"])
            if not Materia.es_nota_valida(nueva_nota): return False, "Nota inválida"
            mt.nota = nueva_nota
            self.guardar()
            return True, f"Nota actualizada a {mt.nota}"
        return False, "Solo se puede actualizar la nota"

    def eliminar(self, id_mt):
        mt = self.obtener(id_mt)
        if not mt: return False, "Matrícula no encontrada"
        mat = self.materias.obtener(mt.materia_id)
        if mat:
            mat.liberar_cupo()
            self.materias.guardar()
        self.lista.remove(mt)
        self.guardar()
        return True, f"Matrícula {id_mt} retirada y cupo devuelto"

    def certificado(self, id_mt):
        mt = self.obtener(id_mt)
        if not mt: return None
        est = self.estudiantes.obtener(mt.estudiante_id)
        mat = self.materias.obtener(mt.materia_id)

        texto = f"CERTIFICADO #{mt.id}   periodo: {mt.periodo}\n"
        texto += f"Estudiante: {est.nombre_completo() if est else 'eliminado'}   ({est.carnet if est else ''})\n"
        texto += f"Materia   : {mat.nombre if mat else 'eliminado'}   ({mat.codigo if mat else ''}) · {mat.creditos if mat else 0} créditos\n"
        texto += "-" * 42 + "\n"
        texto += f"Nota      : {mt.nota}\n"
        texto += f"Estado    : {mt.estado()}"
        return texto

    def total_aprobadas(self):
        return sum(1 for mt in self.lista if mt.esta_aprobada())

