from shared.herramientas import imprimir_titulo, imprimir_exito, imprimir_error, imprimir_info, confirmar
from views import EstudianteController, MateriaController, MatriculaController

# Controladores únicos
estudiantes = EstudianteController()
materias = MateriaController()
matriculas = MatriculaController(estudiantes, materias)

def pausa():
    input("\nPresione Enter para continuar...")

def pedir_entero(etq):
    try: return int(input(etq))
    except ValueError: return None

def mostrar_resultado(exito, mensaje):
    if exito: imprimir_exito(mensaje)
    else: imprimir_error(mensaje)

def mostrar_lista(objetos, vacio="No hay registros."):
    if not objetos:
        imprimir_info(vacio)
        return
    for o in objetos: print(f"  {o}")
    imprimir_info(f"Total: {len(objetos)}")

def mostrar_detalle(objeto):
    for k, v in objeto.a_diccionario().items():
        print(f"  {str(k).replace('_', ' ').capitalize():<16}: {v}")

# --- MENÚ ESTUDIANTES ---
def crear_estudiante():
    imprimir_titulo("CREAR ESTUDIANTE")
    datos = {
        "nombre": input("Nombre: "), "apellido": input("Apellido: "),
        "email": input("Email: "), "carnet": input("Carnet: "), "carrera": input("Carrera: ")
    }
    mostrar_resultado(*estudiantes.crear(datos))
    pausa()

def listar_estudiantes():
    imprimir_titulo("ESTUDIANTES")
    mostrar_lista(estudiantes.leer())
    pausa()

def buscar_estudiante():
    imprimir_titulo("BUSCAR ESTUDIANTE")
    mostrar_lista(estudiantes.buscar(input("Término: ")))
    pausa()

def ver_estudiante():
    imprimir_titulo("VER ESTUDIANTE")
    est = estudiantes.obtener(pedir_entero("Id: "))
    if est: mostrar_detalle(est)
    else: imprimir_error("No encontrado")
    pausa()

def eliminar_estudiante():
    imprimir_titulo("ELIMINAR ESTUDIANTE")
    id_est = pedir_entero("Id: ")
    if id_est and confirmar("¿Confirma eliminar?"):
        mostrar_resultado(*estudiantes.eliminar(id_est))
    pausa()

# --- MENÚ MATERIAS ---
def crear_materia():
    imprimir_titulo("CREAR MATERIA")
    datos = {
        "nombre": input("Nombre: "), "codigo": input("Código (ej MAT101): "),
        "creditos": pedir_entero("Créditos: "), "cupos": pedir_entero("Cupos: ")
    }
    mostrar_resultado(*materias.crear(datos))
    pausa()

def listar_materias():
    imprimir_titulo("MATERIAS")
    mostrar_lista(materias.leer())
    pausa()

def buscar_materia():
    imprimir_titulo("BUSCAR MATERIA")
    mostrar_lista(materias.buscar(input("Término: ")))
    pausa()

# --- MENÚ MATRÍCULAS ---
def registrar_matricula():
    imprimir_titulo("REGISTRAR MATRÍCULA")
    imprimir_info("Estudiantes:")
    mostrar_lista(estudiantes.leer())
    imprimir_info("\nMaterias:")
    mostrar_lista(materias.leer())

    datos = {
        "estudiante_id": pedir_entero("\nId del estudiante: "),
        "materia_id": pedir_entero("Id de la materia: "),
        "periodo": input("Periodo (ej 2026-1): "),
        "nota": float(input("Nota inicial (0 si no tiene): ") or 0)
    }
    mostrar_resultado(*matriculas.crear(datos))
    pausa()

def listar_matriculas():
    imprimir_titulo("MATRÍCULAS")
    mostrar_lista(matriculas.leer())
    pausa()

def ver_certificado():
    imprimir_titulo("CERTIFICADO")
    texto = matriculas.certificado(pedir_entero("Id de matrícula: "))
    if texto: print(texto)
    else: imprimir_error("No existe")
    pausa()

def retirar_matricula():
    imprimir_titulo("RETIRAR MATRÍCULA")
    id_mt = pedir_entero("Id de matrícula: ")
    if id_mt and confirmar("Se devolverá el cupo. ¿Confirma?"):
        mostrar_resultado(*matriculas.eliminar(id_mt))
    pausa()

def resumen():
    imprimir_titulo("RESUMEN ACADÉMICO")
    print(f"  Estudiantes  : {len(estudiantes.leer())}")
    print(f"  Carreras     : {', '.join(estudiantes.carreras()) or '-'}")
    print(f"  Materias     : {len(materias.leer())}")
    print(f"  Matrículas   : {len(matriculas.leer())}")
    print(f"  Aprobadas    : {matriculas.total_aprobadas()}")
    pausa()

# Diccionarios de menús
MENU_EST = {"1": ("Crear", crear_estudiante), "2": ("Ver todos", listar_estudiantes), "3": ("Buscar", buscar_estudiante), "4": ("Ver por id", ver_estudiante), "5": ("Eliminar", eliminar_estudiante), "0": ("Volver", None)}
MENU_MAT = {"1": ("Crear", crear_materia), "2": ("Ver todas", listar_materias), "3": ("Buscar", buscar_materia), "0": ("Volver", None)}
MENU_MT  = {"1": ("Matricular", registrar_matricula), "2": ("Ver todas", listar_matriculas), "3": ("Ver certificado", ver_certificado), "4": ("Retirar", retirar_matricula), "0": ("Volver", None)}

def ejecutar_menu(titulo, opciones):
    while True:
        imprimir_titulo(titulo)
        for t, (desc, _) in opciones.items(): print(f"  {t}. {desc}")
        print()
        tecla = input("Opción: ").strip()
        if tecla not in opciones: continue
        _, func = opciones[tecla]
        if func is None: break
        func()

def main():
    while True:
        imprimir_titulo("SISTEMA ACADÉMICO")
        print("  1. Estudiantes")
        print("  2. Materias")
        print("  3. Matrículas")
        print("  4. Resumen")
        print("  0. Salir\n")
        op = input("Opción: ").strip()
        if op == "1": ejecutar_menu("ESTUDIANTES", MENU_EST)
        elif op == "2": ejecutar_menu("MATERIAS", MENU_MAT)
        elif op == "3": ejecutar_menu("MATRÍCULAS", MENU_MT)
        elif op == "4": resumen()
        elif op == "0": break

if __name__ == "__main__":
    main()


